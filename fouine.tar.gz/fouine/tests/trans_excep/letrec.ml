let rec f x = if x=0 then 0 else f 0 in f 5
