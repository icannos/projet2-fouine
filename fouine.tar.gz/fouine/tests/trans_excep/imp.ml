let a = ref 3 in let b = ref a in prInt !(!b) 
