if 0=0 then prInt 1 else prInt 2 
