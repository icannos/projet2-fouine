let a = 5 in let f x = a * x in let a = 6 in prInt (f 3)
