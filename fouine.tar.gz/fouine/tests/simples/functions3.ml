let f x y = x * y in
    let c = 5 in
    prInt (f c 2)
