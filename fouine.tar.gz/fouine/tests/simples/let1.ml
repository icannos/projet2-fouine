let x = 31 in prInt ((x+1)*52)
	   
