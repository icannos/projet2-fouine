let a = ref 0 in prInt !a; a := 5; prInt !a
