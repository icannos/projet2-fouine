let c = 8 in (fun x -> c*x) 3
