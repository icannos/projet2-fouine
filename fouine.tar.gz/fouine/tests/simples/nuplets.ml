let (x,y,z,t) = (3+2, 8+9 ,56, 14*78) in prInt x; prInt y; prInt z; prInt t
