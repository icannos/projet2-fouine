let f () () () = 3 in

prInt (f () () ())
