let (a,b,c) = (1,2,3) in
prInt a; prInt b; prInt c
