let c = 5 in
let _ = if c = 6 then (prInt 8) else (prInt 7) in
  let _ =
    if c = 5 then (prInt 8) else (prInt 7) in 0
