let f x = prInt x ; ()
let g x = let y = x in () ;;
f 5 ; g ()
