let a = ref 0 in a := 5 
