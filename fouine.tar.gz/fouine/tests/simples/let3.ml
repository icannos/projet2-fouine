let x = 32 ;;
prInt ((let y = 51 in y+1)*x)
