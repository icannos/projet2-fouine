let a = 16
let b = 26
let c = 2*(a*b);;
prInt (2*c)
