let f (a,b) = prInt a in

f (5,8) 
