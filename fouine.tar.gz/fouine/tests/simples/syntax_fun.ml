 (prInt ((fun x y z -> x * y * z) 3 3 3))
