let f x = prInt x; (fun x -> x) in

prInt ((f 5) 8)
