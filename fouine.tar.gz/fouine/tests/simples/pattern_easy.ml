let f x = match x with
  | 0 -> 0
  | 1 -> 1
  | _ -> 10
    in prInt (f 2)

