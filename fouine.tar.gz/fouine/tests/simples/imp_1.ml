let a = ref 0 in prInt !a
