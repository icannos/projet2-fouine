let salut = 5 in
 let lol = 5 + salut in
 let _ = prInt lol in
 let _ = prInt 5 in 0
