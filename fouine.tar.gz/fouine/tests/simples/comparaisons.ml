let a = 42 in
    let b = 18 in
    let _ = if a<b then (prInt 1) else (prInt 2) in
    let _ = if a <> b then (prInt 1) else (prInt 2) in
    let _ = if a <= 43 then (prInt 1) else (prInt 2) in
    let _ = if 2 >= 1 then (prInt 1) else (prInt 2) in 0
