





let c = 0 in let _ = 5/c in 0 
