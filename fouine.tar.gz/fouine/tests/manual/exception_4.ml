try raise (5) with x -> prInt x
