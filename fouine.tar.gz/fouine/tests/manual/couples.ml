
match (2,3) with
|Maxime(x)-> prInt x
|(x,y) -> prInt x
