let Co(x) = Bllee(8) in prInt x 
